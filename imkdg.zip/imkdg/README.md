# IMKDG — In-context Medical Knowledge-grounded Dialogue Generator

PyTorch implementation of the IMKDG framework from:

> **Faithful Medical Dialogue Generation using Homo-Heterogeneous Exemplar-based In-Context Knowledge Grounding**  
> Priyanshu Priya, Hardik Goyal, Asif Ekbal — IIT Patna (LREC 2026)

---

## Architecture Overview

```
IMKDG
├── Medical Knowledge Enrichment (MKE)
│   ├── QuickUMLS entity extractor
│   └── UMLS knowledge graph builder (triplets)
├── Homo-Heterogeneous Exemplar Selection (H2ES)
│   ├── RoBERTa sentence encoder
│   ├── Cosine similarity (relevance)
│   └── Manhattan distance diversity scorer
└── Prompt Construction (PC)
    └── Few-shot prompt assembler
```

---

## Setup

```bash
pip install -r requirements.txt
python -m spacy download en_core_sci_sm   # ScispaCy model for E-F1
```

### QuickUMLS

QuickUMLS requires a local UMLS installation.  
Follow the setup guide at https://github.com/Georgetown-IR-Lab/QuickUMLS  
then set `QUICKUMLS_PATH` in `config.py`.

---

## Project Structure

```
imkdg/
├── config.py                    # All hyperparameters & paths
├── main.py                      # Entry point: train / evaluate / generate
├── requirements.txt
├── data/
│   └── README.md                # Dataset download instructions
├── src/
│   ├── imkdg.py                 # Top-level IMKDG class
│   ├── knowledge/
│   │   ├── entity_extractor.py  # QuickUMLS wrapper
│   │   └── graph_builder.py     # MKG construction from UMLS SN
│   ├── exemplar/
│   │   ├── encoder.py           # RoBERTa sentence encoder (PyTorch)
│   │   └── h2es.py              # H2ES algorithm (Algorithm 1)
│   └── prompt/
│       └── constructor.py       # Prompt template builder
├── evaluation/
│   ├── auto_metrics.py          # PPL, BLEU, METEOR, ROUGE, BERTScore, etc.
│   └── faithfulness.py          # E-F1, FEQA, QuestEval
└── scripts/
    ├── prepare_data.py          # Pre-process MedDialog-EN / CDialog
    └── run_experiment.py        # Full experiment loop
```

---

## Quick Start

```bash
# 1. Prepare data
python scripts/prepare_data.py --dataset meddialog --split 0.7

# 2. Run generation + evaluation
python main.py \
    --dataset meddialog \
    --llm gpt-4 \
    --lambda_ 0.2 \
    --n_relevant 20 \
    --n_exemplars 3

# 3. Ablation study
python main.py --dataset meddialog --llm gpt-4 --ablate knowledge
python main.py --dataset meddialog --llm gpt-4 --ablate exemplars
```

---

## Citation

```bibtex
@inproceedings{priya2026imkdg,
  title={Faithful Medical Dialogue Generation using Homo-Heterogeneous
         Exemplar-based In-Context Knowledge Grounding},
  author={Priya, Priyanshu and Goyal, Hardik and Ekbal, Asif},
  booktitle={LREC 2026},
  year={2026}
}
```
