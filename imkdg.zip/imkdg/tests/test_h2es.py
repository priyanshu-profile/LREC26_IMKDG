"""
tests/test_h2es.py

Unit tests for the H2ES algorithm and surrounding components.
Run with:  python -m pytest tests/ -v
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))

import pytest
import torch

from src.exemplar.encoder import SentenceEncoder
from src.exemplar.h2es import Exemplar, H2ES
from src.knowledge.entity_extractor import MockEntityExtractor
from src.knowledge.graph_builder import KnowledgeGraphBuilder
from src.prompt.constructor import PromptConstructor, INSTRUCTION


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def encoder():
    return SentenceEncoder(model_name="roberta-base", device="cpu", batch_size=8)


@pytest.fixture(scope="module")
def mock_extractor():
    return MockEntityExtractor()


@pytest.fixture(scope="module")
def graph_builder(mock_extractor):
    return KnowledgeGraphBuilder(extractor=mock_extractor, max_triplets=10)


@pytest.fixture(scope="module")
def sample_database():
    return [
        Exemplar(
            dialogue_context="Patient: I have a headache.\nDoctor: How long?",
            knowledge_text="[headache, symptom_or_sign_of, migraine]",
            response="Take ibuprofen and rest.",
        ),
        Exemplar(
            dialogue_context="Patient: I have anxiety.\nDoctor: Since when?",
            knowledge_text="[anxiety, associated_with, Depression]",
            response="Consider therapy and meditation.",
        ),
        Exemplar(
            dialogue_context="Patient: I cough a lot.\nDoctor: Any fever?",
            knowledge_text="[infection, related_to, respiratory system]",
            response="Sounds like a respiratory infection.",
        ),
        Exemplar(
            dialogue_context="Patient: My knee hurts.\nDoctor: After exercise?",
            knowledge_text="[inflammation, affects, joints]",
            response="Rest and apply ice.",
        ),
        Exemplar(
            dialogue_context="Patient: I feel depressed.\nDoctor: How long?",
            knowledge_text="[depression, may_be_treated_by, antidepressants]",
            response="Please see a psychiatrist.",
        ),
    ]


# ---------------------------------------------------------------------------
# SentenceEncoder tests
# ---------------------------------------------------------------------------

class TestSentenceEncoder:
    def test_encode_single(self, encoder):
        emb = encoder.encode("I have a headache.")
        assert emb.shape == (1, 768)
        # Should be L2-normalised
        assert abs(emb.norm().item() - 1.0) < 1e-4

    def test_encode_batch(self, encoder):
        texts = ["Hello world", "Medical diagnosis", "Patient care"]
        emb = encoder.encode(texts)
        assert emb.shape == (3, 768)

    def test_cosine_similarity_range(self, encoder):
        q  = encoder.encode("headache migraine")
        ks = encoder.encode(["headache", "apple", "migraine"])
        sim = encoder.cosine_similarity(q.squeeze(0), ks)
        assert sim.shape == (3,)
        assert (sim >= -1).all() and (sim <= 1).all()

    def test_identical_texts_similarity_one(self, encoder):
        text = "sinusitis infection"
        q  = encoder.encode(text).squeeze(0)
        ks = encoder.encode([text])
        sim = encoder.cosine_similarity(q, ks)
        assert abs(sim.item() - 1.0) < 1e-4

    def test_manhattan_distance_shape(self, encoder):
        a = encoder.encode(["text one", "text two"])
        b = encoder.encode(["other a", "other b", "other c"])
        dist = encoder.manhattan_distance(a, b)
        assert dist.shape == (2, 3)
        assert (dist >= 0).all()


# ---------------------------------------------------------------------------
# H2ES tests
# ---------------------------------------------------------------------------

class TestH2ES:
    @pytest.fixture(autouse=True)
    def setup(self, encoder, sample_database):
        self.h2es = H2ES(encoder=encoder, n_relevant=5, n_exemplars=3, lambda_=0.2)
        # Deep-copy database and index
        import copy
        db = copy.deepcopy(sample_database)
        self.h2es.index(db)

    def test_returns_correct_count(self):
        result = self.h2es.select(
            query_context="Patient: I feel sad and anxious.",
            query_knowledge="[anxiety, associated_with, depression]",
        )
        assert len(result) == 3

    def test_returns_exemplar_objects(self):
        result = self.h2es.select("Patient: I have a headache.", "")
        assert all(isinstance(ex, Exemplar) for ex in result)

    def test_n_exemplars_leq_n_relevant(self):
        with pytest.raises(ValueError):
            _ = H2ES(encoder=None, n_relevant=2, n_exemplars=5)

    def test_no_duplicate_exemplars(self):
        result = self.h2es.select("Patient: Knee pain.", "")
        texts = [ex.dialogue_context for ex in result]
        assert len(texts) == len(set(texts))

    def test_lambda_0_maximises_diversity(self, encoder, sample_database):
        """With λ=0 (pure diversity), exemplars should be maximally spread."""
        import copy
        h2es_div = H2ES(encoder=encoder, n_relevant=5, n_exemplars=3, lambda_=0.0)
        h2es_div.index(copy.deepcopy(sample_database))
        result = h2es_div.select("Patient: headache.", "")
        assert len(result) == 3

    def test_requires_index_before_select(self, encoder):
        fresh = H2ES(encoder=encoder, n_relevant=5, n_exemplars=2, lambda_=0.2)
        with pytest.raises(RuntimeError):
            fresh.select("query", "knowledge")


# ---------------------------------------------------------------------------
# KnowledgeGraphBuilder tests
# ---------------------------------------------------------------------------

class TestKnowledgeGraphBuilder:
    def test_build_returns_triplets(self, graph_builder):
        kg = graph_builder.build(
            "Patient: I have a headache and sinusitis.\nDoctor: How long?"
        )
        assert len(kg.triplets) > 0

    def test_to_text_format(self, graph_builder):
        kg = graph_builder.build("I have anxiety and depression.")
        text = kg.to_text()
        # Should contain bracketed triplets
        if kg.triplets:
            assert "[" in text and "]" in text

    def test_max_triplets_respected(self, mock_extractor):
        builder = KnowledgeGraphBuilder(extractor=mock_extractor, max_triplets=3)
        kg = builder.build("Patient: headache migraine sinusitis anxiety depression coronavirus.")
        assert len(kg.triplets) <= 3

    def test_empty_text_returns_empty_graph(self, graph_builder):
        kg = graph_builder.build("")
        assert len(kg.triplets) == 0


# ---------------------------------------------------------------------------
# PromptConstructor tests
# ---------------------------------------------------------------------------

class TestPromptConstructor:
    def setup_method(self):
        self.pc = PromptConstructor()
        self.exemplars = [
            Exemplar(
                dialogue_context="Patient: headache.\nDoctor: Type?",
                knowledge_text="[headache, symptom_or_sign_of, migraine]",
                response="Likely migraine. Take ibuprofen.",
            )
        ]

    def test_instruction_present(self):
        prompt = self.pc.build("Patient: I am sick.", "no knowledge", self.exemplars)
        assert INSTRUCTION in prompt

    def test_doctor_response_blank_for_target(self):
        prompt = self.pc.build("Patient: Sick.", "", self.exemplars)
        # The last "Doctor Response:" should have nothing after it
        last_dr = prompt.rfind("Doctor Response:")
        tail = prompt[last_dr + len("Doctor Response:"):].strip()
        assert tail == ""

    def test_no_exemplars_produces_zero_shot(self):
        prompt = self.pc.build_vanilla("Patient: I have a cough.")
        # Should still have the instruction
        assert INSTRUCTION in prompt
        # No "We know that" block
        assert "We know that" not in prompt

    def test_ablation_no_knowledge(self):
        prompt = self.pc.build_no_knowledge("Patient: Headache.", self.exemplars)
        assert "We know that" not in prompt

    def test_knowledge_in_full_prompt(self):
        prompt = self.pc.build(
            "Patient: Coronavirus.", "[coronavirus, isa, infection]", self.exemplars
        )
        assert "We know that" in prompt


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
