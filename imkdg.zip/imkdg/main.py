"""
main.py — Quick entry point for IMKDG experiments.

Delegates to scripts/run_experiment.py with the same CLI interface.
"""

import sys
from scripts.run_experiment import main

if __name__ == "__main__":
    main()
