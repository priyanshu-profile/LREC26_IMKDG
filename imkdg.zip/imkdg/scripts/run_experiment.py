"""
scripts/run_experiment.py

Full end-to-end experiment runner for IMKDG.

Reproduces the experimental setup in Section 4:
  - Loads train/test splits
  - Builds exemplar database (indexed with H2ES)
  - Generates responses for the test set
  - Runs automatic + faithfulness evaluations
  - Saves results to outputs/<run_name>/

Usage
-----
    python scripts/run_experiment.py \\
        --dataset meddialog \\
        --llm gpt-4 \\
        --openai \\
        --lambda_ 0.2 \\
        --n_relevant 20 \\
        --n_exemplars 3

    # Ablation: remove medical knowledge
    python scripts/run_experiment.py --dataset meddialog --llm gpt-4 --openai --ablate no_knowledge

    # Ablation: vanilla baseline
    python scripts/run_experiment.py --dataset meddialog --llm gpt-4 --openai --ablate vanilla
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

# Make project root importable when run as a script
sys.path.insert(0, str(Path(__file__).parents[1]))

from src.imkdg import IMKDG, IMKDGConfig, AblationMode
from evaluation.auto_metrics import AutoEvaluator
from evaluation.faithfulness import FaithfulnessEvaluator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

DATA_DIR    = Path(__file__).parents[1] / "data"
OUTPUT_DIR  = Path(__file__).parents[1] / "outputs"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_json(path: Path):
    with path.open() as f:
        return json.load(f)


def save_json(obj, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def print_results(results: dict, title: str = "Results"):
    print(f"\n{'─' * 55}")
    print(f"  {title}")
    print(f"{'─' * 55}")
    for k, v in results.items():
        print(f"  {k:<12} {v:.4f}")
    print(f"{'─' * 55}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Run IMKDG experiment.")

    # Data
    p.add_argument("--dataset",     choices=["meddialog", "cdialog"], default="meddialog")
    p.add_argument("--max_test",    type=int,  default=None,
                   help="Cap test set size (useful for quick trials).")

    # Model
    p.add_argument("--llm",         type=str,  default="gpt-4",
                   help="LLM name (HF model id or OpenAI model string).")
    p.add_argument("--openai",      action="store_true",
                   help="Use OpenAI API instead of local HF model.")
    p.add_argument("--encoder",     type=str,  default="roberta-base")
    p.add_argument("--device",      type=str,  default="cuda")

    # QuickUMLS
    p.add_argument("--quickumls",   type=str,  default="/path/to/quickumls",
                   help="Path to QuickUMLS data dir.")
    p.add_argument("--mock_umls",   action="store_true",
                   help="Use mock UMLS extractor (for testing without UMLS install).")

    # H2ES
    p.add_argument("--n_relevant",  type=int,  default=20)
    p.add_argument("--n_exemplars", type=int,  default=3)
    p.add_argument("--lambda_",     type=float, default=0.2)

    # Ablation
    p.add_argument("--ablate",
                   choices=["full", "no_knowledge", "no_exemplars", "vanilla"],
                   default="full")

    # Evaluation
    p.add_argument("--word_vectors", type=str, default=None,
                   help="Path to GloVe/FastText .txt for EA/VE/GM.")
    p.add_argument("--skip_faithfulness", action="store_true",
                   help="Skip E-F1/FEQA/QE (faster debugging).")

    # Misc
    p.add_argument("--run_name",    type=str, default=None)
    p.add_argument("--seed",        type=int, default=42)

    return p.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = parse_args()

    run_name = args.run_name or f"{args.dataset}_{args.llm}_{args.ablate}_{int(time.time())}"
    out_dir  = OUTPUT_DIR / run_name
    out_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Run: %s  →  %s", run_name, out_dir)

    # ── Load data ──────────────────────────────────────────────────────
    ddir = DATA_DIR / args.dataset
    train_samples = load_json(ddir / "train.json")
    test_samples  = load_json(ddir / "test.json")

    if args.max_test:
        test_samples = test_samples[: args.max_test]
        logger.info("Test set capped at %d samples.", args.max_test)

    logger.info("Dataset: %s | train: %d | test: %d",
                args.dataset, len(train_samples), len(test_samples))

    # ── Build IMKDG ─────────────────────────────────────────────────────
    cfg = IMKDGConfig(
        llm_name=args.llm,
        is_openai=args.openai,
        quickumls_path=args.quickumls,
        encoder_model=args.encoder,
        device=args.device,
        n_relevant=args.n_relevant,
        n_exemplars=args.n_exemplars,
        lambda_=args.lambda_,
        ablation=AblationMode(args.ablate),
        use_mock_umls=args.mock_umls,
    )
    model = IMKDG(cfg)
    model.build_database(train_samples)

    # ── Generate ────────────────────────────────────────────────────────
    logger.info("Generating responses for %d test samples …", len(test_samples))
    hypotheses  = []
    references  = []
    sources     = []    # context + knowledge (for faithfulness metrics)

    for i, sample in enumerate(test_samples, 1):
        ctx  = sample["context"]
        gold = sample["response"]

        hyp = model.generate(ctx)
        hypotheses.append(hyp)
        references.append(gold)

        # Build knowledge text for the source document used in faithfulness eval
        kg = model.graph_builder.build(ctx)
        sources.append(f"{ctx}\n{kg.to_text()}")

        if i % 10 == 0:
            logger.info("  Generated %d / %d", i, len(test_samples))

    # Save raw generations
    gen_output = [
        {"context": s["context"], "gold": s["response"], "generated": h}
        for s, h in zip(test_samples, hypotheses)
    ]
    save_json(gen_output, out_dir / "generations.json")
    logger.info("Saved generations to %s", out_dir / "generations.json")

    # ── Automatic evaluation ────────────────────────────────────────────
    auto_eval = AutoEvaluator(
        word_vectors_path=args.word_vectors,
        device=args.device,
    )
    auto_results = auto_eval.evaluate(hypotheses, references)
    print_results(auto_results, title=f"Automatic Evaluation — {run_name}")
    save_json(auto_results, out_dir / "auto_results.json")

    # ── Faithfulness evaluation ─────────────────────────────────────────
    faith_results: dict = {}
    if not args.skip_faithfulness:
        faith_eval = FaithfulnessEvaluator(device=args.device)
        faith_results = faith_eval.evaluate(hypotheses, sources)
        print_results(faith_results, title="Faithfulness Evaluation")
        save_json(faith_results, out_dir / "faithfulness_results.json")

    # ── Combined results summary ────────────────────────────────────────
    combined = {**auto_results, **faith_results}
    save_json(combined, out_dir / "all_results.json")
    logger.info("All results saved to %s", out_dir)


if __name__ == "__main__":
    main()
