"""
scripts/prepare_data.py

Download and pre-process MedDialog-EN and CDialog datasets.

Usage
-----
    python scripts/prepare_data.py --dataset meddialog --split 0.7
    python scripts/prepare_data.py --dataset cdialog   --split 0.7

Output
------
Each dataset directory gets three JSON files:
    data/<dataset>/train.json
    data/<dataset>/dev.json
    data/<dataset>/test.json

Each JSON file is a list of dicts:
    {
        "context":  "<patient turn 1> \n <doctor turn 1> \n ... <patient turn k>",
        "response": "<gold doctor response>"
    }

The train.json also serves as the exemplar database for H2ES.
"""

import argparse
import json
import logging
import random
from pathlib import Path
from typing import Dict, List, Tuple

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parents[1] / "data"


# ---------------------------------------------------------------------------
# MedDialog-EN
# ---------------------------------------------------------------------------

def load_meddialog() -> List[Dict]:
    """
    Load MedDialog-EN from HuggingFace datasets.
    Falls back to a manual download if the HF version is unavailable.
    """
    try:
        from datasets import load_dataset
        ds = load_dataset("bigbio/med_dialog", "med_dialog_en_bigbio_qa", split="train")
        samples = []
        for row in ds:
            # med_dialog_en has 'context' (list of str) and 'answer' fields
            turns = row.get("context", [])
            answer = row.get("answer", "")
            if not turns or not answer:
                continue
            # Build alternating patient/doctor context string
            context_lines = []
            roles = ["Patient", "Doctor"]
            for i, turn in enumerate(turns):
                role = roles[i % 2]
                context_lines.append(f"{role}: {turn.strip()}")
            # Last turn is always "Patient:" (the question to answer)
            context = "\n".join(context_lines)
            samples.append({"context": context, "response": answer.strip()})
        return samples
    except Exception as e:
        logger.error("HuggingFace load failed (%s). Please download manually.", e)
        return []


# ---------------------------------------------------------------------------
# CDialog
# ---------------------------------------------------------------------------

def load_cdialog(raw_path: Path) -> List[Dict]:
    """
    Load CDialog from a local directory (not on HF Hub publicly).

    Expected format: one JSON file per dialogue with keys
    'utterances' (list of str) and optionally 'responses' (list of str).

    Parameters
    ----------
    raw_path : Path
        Directory containing the raw CDialog JSON files.
    """
    samples = []
    if not raw_path.exists():
        logger.warning("CDialog raw path not found: %s", raw_path)
        return samples

    for jf in sorted(raw_path.glob("*.json")):
        with jf.open() as f:
            dial = json.load(f)

        utterances = dial.get("utterances", [])
        if len(utterances) < 2:
            continue

        # Build context from all turns except the last doctor turn
        context_lines = []
        roles = ["Patient", "Doctor"]
        for i, utt in enumerate(utterances[:-1]):
            context_lines.append(f"{roles[i % 2]}: {utt.strip()}")

        context  = "\n".join(context_lines)
        response = utterances[-1].strip()
        samples.append({"context": context, "response": response})

    logger.info("Loaded %d CDialog samples from %s", len(samples), raw_path)
    return samples


# ---------------------------------------------------------------------------
# Splitting
# ---------------------------------------------------------------------------

def split_dataset(
    samples: List[Dict],
    train_ratio: float = 0.7,
    dev_ratio:   float = 0.2,   # fraction of the training portion
    seed: int = 42,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """
    Split samples into train / dev / test.

    Paper: 7:3 train/test, then 8:2 train/dev within training set.
    """
    random.seed(seed)
    random.shuffle(samples)

    n_test  = int(len(samples) * (1 - train_ratio))
    n_train = len(samples) - n_test
    n_dev   = int(n_train * dev_ratio)

    train_all = samples[:n_train]
    test      = samples[n_train:]
    dev       = train_all[:n_dev]
    train     = train_all[n_dev:]

    return train, dev, test


# ---------------------------------------------------------------------------
# Saving
# ---------------------------------------------------------------------------

def save_split(samples: List[Dict], path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(samples, f, indent=2, ensure_ascii=False)
    logger.info("Saved %d samples to %s", len(samples), path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="Prepare IMKDG datasets.")
    parser.add_argument(
        "--dataset", choices=["meddialog", "cdialog", "both"],
        default="meddialog",
        help="Which dataset to prepare.",
    )
    parser.add_argument("--split",      type=float, default=0.7,
                        help="Train ratio (default: 0.7).")
    parser.add_argument("--dev_ratio",  type=float, default=0.2,
                        help="Dev ratio within training (default: 0.2).")
    parser.add_argument("--cdialog_raw", type=str,
                        default=str(DATA_DIR / "cdialog_raw"),
                        help="Path to raw CDialog JSON files.")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def prepare(dataset_name: str, samples: List[Dict], split: float, dev_ratio: float, seed: int):
    if not samples:
        logger.warning("No samples loaded for %s; skipping.", dataset_name)
        return

    train, dev, test = split_dataset(samples, train_ratio=split,
                                     dev_ratio=dev_ratio, seed=seed)
    out = DATA_DIR / dataset_name
    save_split(train, out / "train.json")
    save_split(dev,   out / "dev.json")
    save_split(test,  out / "test.json")
    logger.info(
        "%s splits — train: %d | dev: %d | test: %d",
        dataset_name, len(train), len(dev), len(test),
    )


def main():
    args = parse_args()

    if args.dataset in ("meddialog", "both"):
        logger.info("Loading MedDialog-EN …")
        samples = load_meddialog()
        prepare("meddialog", samples, args.split, args.dev_ratio, args.seed)

    if args.dataset in ("cdialog", "both"):
        logger.info("Loading CDialog …")
        samples = load_cdialog(Path(args.cdialog_raw))
        prepare("cdialog", samples, args.split, args.dev_ratio, args.seed)


if __name__ == "__main__":
    main()
