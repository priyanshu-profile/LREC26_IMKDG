"""
evaluation/auto_metrics.py

Automatic evaluation metrics used in the paper (Section 4 / Tables 1 & 2):

  General quality:
    - PPL  (Perplexity)
    - B-4  (BLEU-4)
    - MET. (METEOR)
    - R-L  (ROUGE-L)
    - BS-F1 (BERTScore F1)
    - EA   (Embedding Average cosine similarity)
    - VE   (Vector Extrema cosine similarity)
    - GM   (Greedy Matching)

  Faithfulness (see faithfulness.py for E-F1, FEQA, QE):
    — delegated to evaluation/faithfulness.py

All scorers accept lists of strings (hypotheses vs. references).
"""

from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helper: lazy imports (avoid hard-crash when optional deps absent)
# ---------------------------------------------------------------------------

def _require(package: str, install: str):
    try:
        import importlib
        return importlib.import_module(package)
    except ImportError as e:
        raise ImportError(f"Run: pip install {install}") from e


# ---------------------------------------------------------------------------
# Individual scorers
# ---------------------------------------------------------------------------

class BLEUScorer:
    """BLEU-4 via sacrebleu."""

    def __init__(self):
        self._sb = _require("sacrebleu", "sacrebleu")

    def score(self, hypotheses: List[str], references: List[str]) -> float:
        bleu = self._sb.corpus_bleu(hypotheses, [references])
        return bleu.score / 100.0   # return as 0-1 fraction


class METEORScorer:
    """METEOR via NLTK."""

    def __init__(self):
        import nltk
        try:
            nltk.data.find("wordnet")
        except LookupError:
            nltk.download("wordnet", quiet=True)
            nltk.download("punkt", quiet=True)
        self._nltk = nltk

    def score(self, hypotheses: List[str], references: List[str]) -> float:
        scores = [
            self._nltk.translate.meteor_score.meteor_score(
                [ref.split()], hyp.split()
            )
            for hyp, ref in zip(hypotheses, references)
        ]
        return float(np.mean(scores))


class ROUGEScorer:
    """ROUGE-L via rouge_score."""

    def __init__(self):
        from rouge_score import rouge_scorer
        self._scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)

    def score(self, hypotheses: List[str], references: List[str]) -> float:
        scores = [
            self._scorer.score(ref, hyp)["rougeL"].fmeasure
            for hyp, ref in zip(hypotheses, references)
        ]
        return float(np.mean(scores))


class BERTScorer:
    """BERTScore F1 via bert_score library."""

    def __init__(self, model_type: str = "roberta-large", device: str = "cuda"):
        self._bs = _require("bert_score", "bert-score")
        self.model_type = model_type
        self.device = device

    def score(self, hypotheses: List[str], references: List[str]) -> float:
        _, _, f1 = self._bs.score(
            hypotheses, references,
            model_type=self.model_type,
            device=self.device,
            verbose=False,
        )
        return float(f1.mean().item())


class EmbeddingMetrics:
    """
    Embedding-based dialogue metrics:
      - EA  (Embedding Average)
      - VE  (Vector Extrema)
      - GM  (Greedy Matching)

    Reference:
        Liu et al. (2016) "How Not to Evaluate Your Dialogue System"
    """

    def __init__(self, word_vectors_path: Optional[str] = None):
        """
        Parameters
        ----------
        word_vectors_path : str | None
            Path to a GloVe / FastText `.txt` file.
            If None, falls back to the sentence-transformers package for
            sentence-level EA (exact paper reproduction requires GloVe).
        """
        self._wv: Optional[Dict[str, np.ndarray]] = None
        if word_vectors_path:
            self._wv = self._load_vectors(word_vectors_path)

    @staticmethod
    def _load_vectors(path: str) -> Dict[str, np.ndarray]:
        logger.info("Loading word vectors from %s …", path)
        vecs: Dict[str, np.ndarray] = {}
        with open(path, encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip().split(" ")
                word = parts[0]
                vecs[word] = np.array(parts[1:], dtype=np.float32)
        logger.info("Loaded %d word vectors.", len(vecs))
        return vecs

    def _sentence_vector(self, text: str) -> np.ndarray:
        """Return the embedding average vector for a sentence."""
        if self._wv is None:
            raise RuntimeError("word_vectors_path not set; cannot compute EA/VE/GM.")
        tokens = text.lower().split()
        vecs = [self._wv[t] for t in tokens if t in self._wv]
        if not vecs:
            dim = next(iter(self._wv.values())).shape[0]
            return np.zeros(dim, dtype=np.float32)
        return np.mean(vecs, axis=0)

    def _extrema_vector(self, text: str) -> np.ndarray:
        """Return the extrema vector (max-abs per dimension) for a sentence."""
        if self._wv is None:
            raise RuntimeError("word_vectors_path not set.")
        tokens = text.lower().split()
        vecs = [self._wv[t] for t in tokens if t in self._wv]
        if not vecs:
            dim = next(iter(self._wv.values())).shape[0]
            return np.zeros(dim, dtype=np.float32)
        mat = np.stack(vecs)
        pos = mat.max(axis=0)
        neg = mat.min(axis=0)
        return np.where(np.abs(pos) >= np.abs(neg), pos, neg)

    @staticmethod
    def _cosine(a: np.ndarray, b: np.ndarray) -> float:
        denom = np.linalg.norm(a) * np.linalg.norm(b)
        return float(np.dot(a, b) / denom) if denom > 1e-9 else 0.0

    # ── Public ──────────────────────────────────────────────────────────

    def embedding_average(self, hypotheses: List[str], references: List[str]) -> float:
        scores = [
            self._cosine(self._sentence_vector(h), self._sentence_vector(r))
            for h, r in zip(hypotheses, references)
        ]
        return float(np.mean(scores))

    def vector_extrema(self, hypotheses: List[str], references: List[str]) -> float:
        scores = [
            self._cosine(self._extrema_vector(h), self._extrema_vector(r))
            for h, r in zip(hypotheses, references)
        ]
        return float(np.mean(scores))

    def greedy_matching(self, hypotheses: List[str], references: List[str]) -> float:
        """Greedy word-level matching (average of forward & backward)."""
        def _gm_one(hyp: str, ref: str) -> float:
            hyp_toks = hyp.lower().split()
            ref_toks = ref.lower().split()
            if not hyp_toks or not ref_toks:
                return 0.0
            if self._wv is None:
                return 0.0
            hyp_vecs = [self._wv[t] for t in hyp_toks if t in self._wv]
            ref_vecs = [self._wv[t] for t in ref_toks if t in self._wv]
            if not hyp_vecs or not ref_vecs:
                return 0.0

            # Forward: for each hyp token find max cosine to any ref token
            fwd = np.mean([max(self._cosine(hv, rv) for rv in ref_vecs) for hv in hyp_vecs])
            # Backward
            bwd = np.mean([max(self._cosine(rv, hv) for hv in hyp_vecs) for rv in ref_vecs])
            return float((fwd + bwd) / 2)

        return float(np.mean([_gm_one(h, r) for h, r in zip(hypotheses, references)]))


class PerplexityScorer:
    """
    Compute perplexity of hypotheses under a language model.

    Parameters
    ----------
    model_name : str
        HuggingFace causal LM to score with.  Default: gpt2.
    device : str
    """

    def __init__(self, model_name: str = "gpt2", device: str = "cuda"):
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        self.model.eval()

    def score(self, hypotheses: List[str]) -> float:
        nlls: List[float] = []
        for text in hypotheses:
            enc = self.tokenizer(text, return_tensors="pt").to(self.device)
            with torch.no_grad():
                loss = self.model(**enc, labels=enc["input_ids"]).loss
            nlls.append(loss.item())
        return math.exp(float(np.mean(nlls)))


# ---------------------------------------------------------------------------
# Unified evaluation runner
# ---------------------------------------------------------------------------

class AutoEvaluator:
    """
    Runs all automatic metrics and returns a results dictionary.

    Parameters
    ----------
    word_vectors_path : str | None
        Path to GloVe / FastText file (required for EA, VE, GM).
    device : str
    bertscore_model : str
    ppl_model : str
    """

    def __init__(
        self,
        word_vectors_path: Optional[str] = None,
        device: str = "cuda",
        bertscore_model: str = "roberta-large",
        ppl_model: str = "gpt2",
    ):
        self.bleu    = BLEUScorer()
        self.meteor  = METEORScorer()
        self.rouge   = ROUGEScorer()
        self.bscore  = BERTScorer(model_type=bertscore_model, device=device)
        self.emb     = EmbeddingMetrics(word_vectors_path)
        self.ppl     = PerplexityScorer(ppl_model, device=device)

    def evaluate(
        self,
        hypotheses: List[str],
        references: List[str],
    ) -> Dict[str, float]:
        """
        Parameters
        ----------
        hypotheses : generated doctor responses
        references : gold-standard doctor responses

        Returns
        -------
        dict with keys: PPL, B-4, MET, R-L, BS-F1, EA, VE, GM
        """
        logger.info("Running automatic evaluation on %d samples …", len(hypotheses))
        results: Dict[str, float] = {}

        results["PPL"]   = self.ppl.score(hypotheses)
        results["B-4"]   = self.bleu.score(hypotheses, references)
        results["MET"]   = self.meteor.score(hypotheses, references)
        results["R-L"]   = self.rouge.score(hypotheses, references)
        results["BS-F1"] = self.bscore.score(hypotheses, references)

        if self.emb._wv is not None:
            results["EA"] = self.emb.embedding_average(hypotheses, references)
            results["VE"] = self.emb.vector_extrema(hypotheses, references)
            results["GM"] = self.emb.greedy_matching(hypotheses, references)
        else:
            logger.warning("Word vectors not provided; skipping EA, VE, GM.")
            results["EA"] = results["VE"] = results["GM"] = float("nan")

        return results
