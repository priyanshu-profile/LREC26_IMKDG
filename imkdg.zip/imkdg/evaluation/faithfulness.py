"""
evaluation/faithfulness.py

Faithfulness evaluation metrics (Section 4 / Tables 1 & 2):

  - E-F1    : Entity Coverage F1 (Ji et al., 2023)
              Measures whether medical entities in generated responses
              align with those in the dialogue context + knowledge graph.
  - FEQA    : Faithfulness via QA (Durmus et al., 2020)
  - QE      : QuestEval (Scialom et al., 2021)

Higher scores on all three indicate fewer hallucinations.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# E-F1 — Entity Coverage F1
# ---------------------------------------------------------------------------

class EntityF1Scorer:
    """
    Compute E-F1 between generated responses and (dialogue context + knowledge).

    Pipeline:
      1. Extract medical named entities from the generated response using
         a ScispaCy NER model.
      2. Extract medical named entities from the reference source
         (dialogue context + knowledge triplet text).
      3. Compute token-level exact-match F1 between the two entity sets.

    Parameters
    ----------
    spacy_model : str
        ScispaCy model to use.  ``"en_core_sci_sm"`` (small, fast) or
        ``"en_core_sci_lg"`` (large, more accurate).
    """

    def __init__(self, spacy_model: str = "en_core_sci_sm"):
        try:
            import spacy
            self._nlp = spacy.load(spacy_model)
        except OSError:
            raise OSError(
                f"ScispaCy model '{spacy_model}' not found. "
                f"Run: pip install scispacy && python -m spacy download {spacy_model}"
            )

    def _extract_entities(self, text: str) -> Set[str]:
        doc = self._nlp(text)
        return {ent.text.lower().strip() for ent in doc.ents}

    @staticmethod
    def _f1(pred: Set[str], gold: Set[str]) -> float:
        if not pred and not gold:
            return 1.0
        if not pred or not gold:
            return 0.0
        tp = len(pred & gold)
        precision = tp / len(pred)
        recall    = tp / len(gold)
        if precision + recall == 0:
            return 0.0
        return 2 * precision * recall / (precision + recall)

    def score(
        self,
        hypotheses: List[str],
        sources: List[str],    # dialogue_context + knowledge_text per sample
    ) -> float:
        """
        Parameters
        ----------
        hypotheses : generated doctor responses
        sources    : dialogue_context concatenated with knowledge_text

        Returns
        -------
        Mean E-F1 across all samples (as a percentage, 0-100).
        """
        scores = []
        for hyp, src in zip(hypotheses, sources):
            pred_ents = self._extract_entities(hyp)
            gold_ents = self._extract_entities(src)
            scores.append(self._f1(pred_ents, gold_ents))
        return float(100.0 * sum(scores) / len(scores))


# ---------------------------------------------------------------------------
# FEQA — Faithfulness via Question-Answering
# ---------------------------------------------------------------------------

class FEQAScorer:
    """
    FEQA (Durmus et al., 2020):
      1. Generate questions from the *source* (dialogue + knowledge).
      2. Answer those questions using the *hypothesis* (generated response).
      3. Score = fraction of questions answered correctly.

    This implementation uses HuggingFace QA pipelines as a practical
    approximation; exact reproduction would use the original FEQA repo.

    Parameters
    ----------
    qg_model  : str   Question-generation model.
    qa_model  : str   Extractive QA model.
    device    : int   -1 for CPU, 0+ for GPU index.
    """

    def __init__(
        self,
        qg_model: str = "valhalla/t5-small-qg-hl",
        qa_model: str = "deepset/roberta-base-squad2",
        device: int = 0,
    ):
        from transformers import pipeline

        self._qg = pipeline("text2text-generation", model=qg_model, device=device)
        self._qa = pipeline("question-answering",   model=qa_model,  device=device)

    def _generate_questions(self, source: str, n: int = 5) -> List[str]:
        """Generate up to ``n`` questions from the source text."""
        prompt = f"generate questions: {source}"
        output = self._qg(prompt, max_length=128, num_return_sequences=n, num_beams=n)
        questions = []
        for item in output:
            for q in item["generated_text"].split("?"):
                q = q.strip()
                if len(q) > 5:
                    questions.append(q + "?")
        return questions[:n]

    def _answer_match(self, question: str, context: str, reference: str) -> float:
        """Return 1.0 if the QA model's answer overlaps with the reference answer."""
        try:
            result = self._qa({"question": question, "context": context})
            pred   = result["answer"].lower()
            ref    = reference.lower()
            # Token-level F1 (simplified)
            pred_toks = set(pred.split())
            ref_toks  = set(ref.split())
            if not pred_toks or not ref_toks:
                return 0.0
            tp = len(pred_toks & ref_toks)
            return (2 * tp / (len(pred_toks) + len(ref_toks))) if tp else 0.0
        except Exception:
            return 0.0

    def score(
        self,
        hypotheses: List[str],
        sources: List[str],
    ) -> float:
        """
        Returns
        -------
        Mean FEQA score (0-100) across all samples.
        """
        all_scores: List[float] = []
        for hyp, src in zip(hypotheses, sources):
            questions = self._generate_questions(src)
            if not questions:
                all_scores.append(0.0)
                continue
            q_scores = []
            for q in questions:
                # Answer question from the hypothesis; compare to answer from source
                hyp_ans = self._qa({"question": q, "context": hyp})["answer"]
                src_ans = self._qa({"question": q, "context": src})["answer"]
                q_scores.append(self._answer_match(q, hyp, src_ans))
            all_scores.append(float(sum(q_scores) / len(q_scores)))
        return 100.0 * sum(all_scores) / len(all_scores)


# ---------------------------------------------------------------------------
# QuestEval
# ---------------------------------------------------------------------------

class QuestEvalScorer:
    """
    QuestEval (Scialom et al., 2021) faithfulness scorer.

    Uses the ``questeval`` library when available; otherwise falls back to
    the same QA-based approximation used in FEQAScorer.

    Parameters
    ----------
    use_questeval_lib : bool
        True → use the official ``questeval`` package (pip install questeval).
        False → use the internal FEQA-style approximation.
    """

    def __init__(self, use_questeval_lib: bool = True, device: str = "cuda"):
        self._qe = None
        if use_questeval_lib:
            try:
                from questeval.questeval_metric import QuestEval
                self._qe = QuestEval(no_cuda=(device == "cpu"))
                logger.info("QuestEval library loaded.")
            except ImportError:
                logger.warning(
                    "questeval not installed (pip install questeval). "
                    "Falling back to FEQA approximation."
                )
        if self._qe is None:
            self._fallback = FEQAScorer(device=0 if device != "cpu" else -1)

    def score(
        self,
        hypotheses: List[str],
        sources: List[str],
    ) -> float:
        if self._qe is not None:
            result = self._qe.corpus_questeval(
                hypothesis=hypotheses,
                sources=sources,
            )
            return float(result["ex_level_scores"].mean() * 100)
        # Fallback
        return self._fallback.score(hypotheses, sources)


# ---------------------------------------------------------------------------
# Unified faithfulness evaluator
# ---------------------------------------------------------------------------

class FaithfulnessEvaluator:
    """
    Runs E-F1, FEQA, and QuestEval together.

    Parameters
    ----------
    spacy_model        : str
    qg_model / qa_model: str  (HF model IDs)
    use_questeval_lib  : bool
    device             : str
    """

    def __init__(
        self,
        spacy_model: str = "en_core_sci_sm",
        qg_model:    str = "valhalla/t5-small-qg-hl",
        qa_model:    str = "deepset/roberta-base-squad2",
        use_questeval_lib: bool = True,
        device: str = "cuda",
    ):
        self.ef1    = EntityF1Scorer(spacy_model)
        self.feqa   = FEQAScorer(qg_model, qa_model, device=0 if device != "cpu" else -1)
        self.qe     = QuestEvalScorer(use_questeval_lib, device=device)

    def evaluate(
        self,
        hypotheses: List[str],
        sources: List[str],   # dialogue_context + knowledge_text
    ) -> Dict[str, float]:
        """
        Parameters
        ----------
        hypotheses : generated responses
        sources    : source documents (context + knowledge)

        Returns
        -------
        dict with keys: E-F1, FEQA, QE
        """
        logger.info("Running faithfulness evaluation …")
        return {
            "E-F1": self.ef1.score(hypotheses, sources),
            "FEQA": self.feqa.score(hypotheses, sources),
            "QE":   self.qe.score(hypotheses, sources),
        }
