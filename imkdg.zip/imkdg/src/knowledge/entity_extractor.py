"""
src/knowledge/entity_extractor.py

Wraps QuickUMLS to extract biomedical named entities and their
CUIs / semantic types from raw dialogue text, as described in
Section 3.2 (Medical Knowledge Enrichment).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class MedicalEntity:
    """A single UMLS concept extracted from text."""
    text: str                    # surface form in dialogue
    cui: str                     # UMLS Concept Unique Identifier
    semantic_types: List[str]    # e.g. ["Disease or Syndrome"]
    similarity: float            # QuickUMLS match score (0-1)
    start: int = 0               # character offset in source text
    end: int   = 0


# ---------------------------------------------------------------------------
# Extractor
# ---------------------------------------------------------------------------

class EntityExtractor:
    """
    Extracts biomedical entities from dialogue text using QuickUMLS.

    QuickUMLS performs approximate string matching against the UMLS
    Metathesaurus, returning CUIs and semantic types for each match.

    Parameters
    ----------
    quickumls_path : str
        Path to the QuickUMLS data directory (contains `cui-semtypes.db` etc.)
    similarity_threshold : float
        Minimum match score to accept (paper uses default ≈ 0.7).
    accepted_semtypes : set | None
        If provided, only entities whose semantic type is in this set are kept.
        ``None`` keeps all types.
    """

    def __init__(
        self,
        quickumls_path: str,
        similarity_threshold: float = 0.7,
        accepted_semtypes: Optional[set] = None,
    ):
        self.quickumls_path = quickumls_path
        self.threshold = similarity_threshold
        self.accepted_semtypes = accepted_semtypes
        self._matcher = self._load_matcher()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_matcher(self):
        """Lazy-load QuickUMLS matcher (avoids import cost at module level)."""
        try:
            from quickumls import QuickUMLS
            matcher = QuickUMLS(
                self.quickumls_path,
                threshold=self.threshold,
                similarity_name="jaccard",
                accepted_semtypes=self.accepted_semtypes,
            )
            logger.info("QuickUMLS matcher loaded from %s", self.quickumls_path)
            return matcher
        except ImportError as exc:
            raise ImportError(
                "quickumls is not installed. Run: pip install quickumls"
            ) from exc
        except Exception as exc:
            raise RuntimeError(
                f"Failed to load QuickUMLS from {self.quickumls_path}: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract(self, text: str) -> List[MedicalEntity]:
        """
        Extract medical entities from ``text``.

        Parameters
        ----------
        text : str
            A dialogue utterance or full dialogue context.

        Returns
        -------
        List[MedicalEntity]
            Deduplicated list of matched UMLS concepts, sorted by
            similarity score (descending).
        """
        raw_matches = self._matcher.match(text, best_match=True, ignore_syntax=False)

        entities: List[MedicalEntity] = []
        seen_cuis: set[str] = set()

        for phrase_matches in raw_matches:
            # QuickUMLS returns a list of candidates per phrase; take best
            for match in phrase_matches:
                cui = match["cui"]
                if cui in seen_cuis:
                    continue
                semtypes = list(match.get("semtypes", []))
                entity = MedicalEntity(
                    text=match["ngram"],
                    cui=cui,
                    semantic_types=semtypes,
                    similarity=match["similarity"],
                    start=match["start"],
                    end=match["end"],
                )
                entities.append(entity)
                seen_cuis.add(cui)

        return sorted(entities, key=lambda e: e.similarity, reverse=True)

    def extract_cuis(self, text: str) -> List[str]:
        """Convenience method returning only CUI strings."""
        return [e.cui for e in self.extract(text)]


# ---------------------------------------------------------------------------
# Stub for unit-testing without a live UMLS installation
# ---------------------------------------------------------------------------

class MockEntityExtractor(EntityExtractor):
    """
    Drop-in replacement that returns hand-crafted entities.
    Useful for CI / unit tests that run without a local UMLS snapshot.
    """

    _MOCK_MAP = {
        "headache":   ("C0018681", ["Sign or Symptom"]),
        "migraine":   ("C0149931", ["Disease or Syndrome"]),
        "sinusitis":  ("C0037199", ["Disease or Syndrome"]),
        "anxiety":    ("C0003469", ["Mental or Behavioral Dysfunction"]),
        "depression": ("C0011570", ["Mental or Behavioral Dysfunction"]),
        "coronavirus":("C0206750", ["Virus"]),
        "pneumonia":  ("C0032285", ["Disease or Syndrome"]),
        "infection":  ("C3714514", ["Disease or Syndrome"]),
    }

    def __init__(self, *args, **kwargs):
        # Skip the real QuickUMLS load
        pass

    def extract(self, text: str) -> List[MedicalEntity]:
        text_lower = text.lower()
        entities = []
        seen: set[str] = set()
        for term, (cui, semtypes) in self._MOCK_MAP.items():
            if term in text_lower and cui not in seen:
                idx = text_lower.index(term)
                entities.append(MedicalEntity(
                    text=term,
                    cui=cui,
                    semantic_types=semtypes,
                    similarity=1.0,
                    start=idx,
                    end=idx + len(term),
                ))
                seen.add(cui)
        return entities
