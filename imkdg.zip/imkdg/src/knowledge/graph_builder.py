"""
src/knowledge/graph_builder.py

Constructs a Medical Knowledge Graph (MKG) for a given dialogue context.

Pipeline (Section 3.2 – Medical Knowledge Enrichment):
  1. Extract entities (CUIs) via EntityExtractor.
  2. For each CUI, query the UMLS Semantic Network (SN) to retrieve
     relationships between semantic types.
  3. Return a list of (head, relation, tail) triplets to include in the prompt.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from src.knowledge.entity_extractor import EntityExtractor, MedicalEntity

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

Triplet = Tuple[str, str, str]   # (entity_1, relation, entity_2)


@dataclass
class KnowledgeGraph:
    """
    Lightweight container for MKG triplets associated with one dialogue.

    Attributes
    ----------
    entities : list of MedicalEntity
        All extracted entities.
    triplets : list of Triplet
        (head_label, relation, tail_label) triples drawn from UMLS SN.
    """
    entities: List[MedicalEntity]
    triplets: List[Triplet]

    def to_text(self) -> str:
        """Serialise as the bracketed triplet format used in the paper's prompts.

        Example output::
            [coronavirus, isa, infection], [coronavirus, related_to, immune system]
        """
        return ", ".join(f"[{h}, {r}, {t}]" for h, r, t in self.triplets)

    def __len__(self) -> int:
        return len(self.triplets)

    def __repr__(self) -> str:
        return f"KnowledgeGraph(entities={len(self.entities)}, triplets={len(self.triplets)})"


# ---------------------------------------------------------------------------
# UMLS Semantic Network relation table
# ---------------------------------------------------------------------------
# The real UMLS SN contains ~54 relation types between ~133 semantic types.
# Below is a representative subset used for approximate reproduction.
# For full coverage, load the official SRREL file from your UMLS installation:
#   <UMLS>/NET/SRREL
#
# Format:  {semantic_type: [(relation, related_semantic_type), ...]}
UMLS_SN_RELATIONS: Dict[str, List[Tuple[str, str]]] = {
    "Disease or Syndrome": [
        ("may_be_treated_by", "Pharmacologic Substance"),
        ("associated_with",   "Sign or Symptom"),
        ("affects",           "Body Part, Organ, or Organ Component"),
        ("isa",               "Pathologic Function"),
    ],
    "Sign or Symptom": [
        ("symptom_or_sign_of", "Disease or Syndrome"),
        ("associated_with",    "Finding"),
    ],
    "Pharmacologic Substance": [
        ("treats",    "Disease or Syndrome"),
        ("inhibits",  "Biologic Function"),
    ],
    "Virus": [
        ("isa",       "Organism"),
        ("related_to","Immune System"),
        ("affects",   "Body System"),
    ],
    "Injury or Poisoning": [
        ("results_in", "Finding"),
        ("affects",    "Body Part, Organ, or Organ Component"),
    ],
    "Bacterium": [
        ("isa",       "Organism"),
        ("causes",    "Disease or Syndrome"),
    ],
    "Diagnostic Procedure": [
        ("diagnoses", "Disease or Syndrome"),
        ("evaluates", "Finding"),
    ],
    "Therapeutic or Preventive Procedure": [
        ("treats",    "Disease or Syndrome"),
        ("prevents",  "Disease or Syndrome"),
    ],
    "Mental or Behavioral Dysfunction": [
        ("associated_with", "Sign or Symptom"),
        ("may_be_treated_by", "Pharmacologic Substance"),
    ],
    "Infectious Disease": [                   # used in paper examples
        ("focus_of",              "Handwashing precautions"),
        ("focus_of",              "Respiratory secretion precautions"),
        ("focus_of",              "Standard precautions"),
        ("possibly_equivalent_to","Non-human infectious disorder"),
        ("associated_with",       "Infectious bronchiolitis"),
    ],
}


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------

class KnowledgeGraphBuilder:
    """
    Builds a Medical Knowledge Graph (MKG) for a dialogue context.

    Parameters
    ----------
    extractor : EntityExtractor
        Configured entity extractor (QuickUMLS or Mock).
    max_triplets : int
        Maximum number of triplets to include per dialogue (prevents
        context-window overflow).
    srrel_path : str | None
        Optional path to the UMLS SRREL file for full SN coverage.
        If None, the built-in subset table is used.
    """

    def __init__(
        self,
        extractor: EntityExtractor,
        max_triplets: int = 20,
        srrel_path: Optional[str] = None,
    ):
        self.extractor = extractor
        self.max_triplets = max_triplets
        self._sn = self._load_sn(srrel_path)

    # ------------------------------------------------------------------
    # Semantic Network loading
    # ------------------------------------------------------------------

    def _load_sn(self, path: Optional[str]) -> Dict[str, List[Tuple[str, str]]]:
        if path is None:
            return UMLS_SN_RELATIONS
        p = Path(path)
        if not p.exists():
            logger.warning("SRREL file not found at %s; using built-in SN table.", path)
            return UMLS_SN_RELATIONS
        logger.info("Loading UMLS Semantic Network from %s", path)
        sn: Dict[str, List[Tuple[str, str]]] = {}
        with p.open() as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) < 5:
                    continue
                src_type, relation, tgt_type = parts[0], parts[2], parts[4]
                sn.setdefault(src_type, []).append((relation, tgt_type))
        return sn

    # ------------------------------------------------------------------
    # Triplet construction
    # ------------------------------------------------------------------

    def _entity_triplets(self, entity: MedicalEntity) -> List[Triplet]:
        """Generate triplets for one entity from the SN relation table."""
        triplets: List[Triplet] = []
        for sem_type in entity.semantic_types:
            for relation, target_type in self._sn.get(sem_type, []):
                triplets.append((entity.text, relation, target_type))
        return triplets

    def _cross_triplets(self, entities: List[MedicalEntity]) -> List[Triplet]:
        """
        Generate entity-to-entity triplets when two entities co-occur and
        share a SN relation (approximates the UMLS SN path-based linking).
        """
        triplets: List[Triplet] = []
        for i, e1 in enumerate(entities):
            for e2 in entities[i + 1:]:
                for st1 in e1.semantic_types:
                    for relation, tgt_st in self._sn.get(st1, []):
                        if any(tgt_st in st for st in e2.semantic_types):
                            triplets.append((e1.text, relation, e2.text))
        return triplets

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(self, dialogue_context: str) -> KnowledgeGraph:
        """
        Build a MKG for the given dialogue text.

        Parameters
        ----------
        dialogue_context : str
            The full dialogue history as a single string.

        Returns
        -------
        KnowledgeGraph
        """
        entities = self.extractor.extract(dialogue_context)

        triplets: List[Triplet] = []

        # 1. Intra-entity triplets (entity ↔ semantic type)
        for entity in entities:
            triplets.extend(self._entity_triplets(entity))

        # 2. Cross-entity triplets (entity ↔ entity via SN)
        triplets.extend(self._cross_triplets(entities))

        # Deduplicate preserving order
        seen: set[Triplet] = set()
        unique: List[Triplet] = []
        for t in triplets:
            if t not in seen:
                seen.add(t)
                unique.append(t)

        return KnowledgeGraph(
            entities=entities,
            triplets=unique[: self.max_triplets],
        )
