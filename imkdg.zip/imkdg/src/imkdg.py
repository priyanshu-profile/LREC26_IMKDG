"""
src/imkdg.py

Top-level IMKDG (In-context Medical Knowledge-grounded Dialogue Generator).

This class wires together the three modules:
  1. Medical Knowledge Enrichment (MKE)
  2. Homo-Heterogeneous Exemplar Selection (H2ES)
  3. Prompt Construction (PC)

and exposes a clean interface for the main experiment loop.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from src.knowledge.entity_extractor import EntityExtractor
from src.knowledge.graph_builder import KnowledgeGraphBuilder
from src.exemplar.encoder import SentenceEncoder
from src.exemplar.h2es import Exemplar, H2ES
from src.prompt.constructor import PromptConstructor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ablation modes
# ---------------------------------------------------------------------------

class AblationMode(str, Enum):
    FULL         = "full"         # complete IMKDG
    NO_KNOWLEDGE = "no_knowledge" # IMKDG w/o K
    NO_EXEMPLARS = "no_exemplars" # IMKDG w/o E
    VANILLA      = "vanilla"      # no K, no E (vanilla LLM baseline)


# ---------------------------------------------------------------------------
# LLM back-end (thin wrapper)
# ---------------------------------------------------------------------------

class LLMBackend:
    """
    Thin wrapper around different LLM inference backends.

    Supports:
      - OpenAI API (ChatGPT, GPT-4)
      - HuggingFace generate() for local models (BioGPT, MedAlpaca, etc.)

    Parameters
    ----------
    model_name : str
        HuggingFace model id or OpenAI model string.
    is_openai : bool
        True for OpenAI-hosted models.
    temperature : float
        Sampling temperature. Paper sets this to 0.
    max_new_tokens : int
        Maximum tokens to generate.
    """

    def __init__(
        self,
        model_name: str,
        is_openai: bool = False,
        temperature: float = 0.0,
        max_new_tokens: int = 512,
        device: str = "cuda",
    ):
        self.model_name = model_name
        self.is_openai = is_openai
        self.temperature = temperature
        self.max_new_tokens = max_new_tokens
        self.device = device

        if is_openai:
            self._init_openai()
        else:
            self._init_hf()

    def _init_openai(self):
        try:
            from openai import OpenAI
            self._client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
            logger.info("OpenAI client initialised for model %s", self.model_name)
        except ImportError as e:
            raise ImportError("Install openai: pip install openai") from e

    def _init_hf(self):
        from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
        import torch

        logger.info("Loading HF model %s …", self.model_name)
        self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self._hf_model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=torch.float16 if self.device != "cpu" else torch.float32,
            device_map="auto",
        )
        self._pipeline = pipeline(
            "text-generation",
            model=self._hf_model,
            tokenizer=self._tokenizer,
            max_new_tokens=self.max_new_tokens,
            temperature=self.temperature,
            do_sample=self.temperature > 0,
        )
        logger.info("HF model loaded.")

    def generate(self, prompt: str) -> str:
        """Run inference and return the generated doctor response string."""
        if self.is_openai:
            return self._openai_generate(prompt)
        return self._hf_generate(prompt)

    def _openai_generate(self, prompt: str) -> str:
        response = self._client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.temperature,
            max_tokens=self.max_new_tokens,
        )
        return response.choices[0].message.content.strip()

    def _hf_generate(self, prompt: str) -> str:
        output = self._pipeline(prompt)[0]["generated_text"]
        # Strip the prompt prefix — keep only what the model generated
        if output.startswith(prompt):
            output = output[len(prompt):]
        # Extract only the Doctor Response section
        marker = "Doctor Response:"
        if marker in output:
            output = output.split(marker)[-1]
        return output.strip()


# ---------------------------------------------------------------------------
# IMKDG
# ---------------------------------------------------------------------------

@dataclass
class IMKDGConfig:
    """Runtime configuration for one IMKDG experiment."""
    llm_name:      str          = "gpt-4"
    is_openai:     bool         = True
    quickumls_path: str         = "/path/to/quickumls"
    encoder_model:  str         = "roberta-base"
    device:         str         = "cuda"
    n_relevant:     int         = 20
    n_exemplars:    int         = 3
    lambda_:        float       = 0.2
    max_triplets:   int         = 20
    temperature:    float       = 0.0
    max_new_tokens: int         = 512
    ablation:       AblationMode = AblationMode.FULL
    use_mock_umls:  bool         = False   # set True for unit testing


class IMKDG:
    """
    In-context Medical Knowledge-grounded Dialogue Generator.

    Orchestrates MKE → H2ES → PC → LLM.

    Parameters
    ----------
    config : IMKDGConfig
    """

    def __init__(self, config: IMKDGConfig):
        self.cfg = config

        # ── 1. Medical Knowledge Enrichment ──────────────────────────
        if config.use_mock_umls:
            from src.knowledge.entity_extractor import MockEntityExtractor
            extractor = MockEntityExtractor()
        else:
            extractor = EntityExtractor(config.quickumls_path)

        self.graph_builder = KnowledgeGraphBuilder(
            extractor=extractor,
            max_triplets=config.max_triplets,
        )

        # ── 2. H2ES exemplar selector ─────────────────────────────────
        self.encoder = SentenceEncoder(
            model_name=config.encoder_model,
            device=config.device,
        )
        self.h2es = H2ES(
            encoder=self.encoder,
            n_relevant=config.n_relevant,
            n_exemplars=config.n_exemplars,
            lambda_=config.lambda_,
        )

        # ── 3. Prompt construction ────────────────────────────────────
        self.pc = PromptConstructor()

        # ── LLM ───────────────────────────────────────────────────────
        self.llm = LLMBackend(
            model_name=config.llm_name,
            is_openai=config.is_openai,
            temperature=config.temperature,
            max_new_tokens=config.max_new_tokens,
            device=config.device,
        )

    # ------------------------------------------------------------------
    # Database setup (call once before generate())
    # ------------------------------------------------------------------

    def build_database(self, train_samples: List[dict]) -> None:
        """
        Build the exemplar database from training samples and pre-index embeddings.

        Parameters
        ----------
        train_samples : list of dict
            Each dict must contain:
              - ``"context"``  — patient-doctor dialogue history (str)
              - ``"response"`` — gold doctor response (str)
        """
        logger.info("Building exemplar database from %d training samples …", len(train_samples))
        database: List[Exemplar] = []
        for sample in train_samples:
            context  = sample["context"]
            response = sample["response"]

            # Build knowledge for each training instance
            kg = self.graph_builder.build(context)

            database.append(Exemplar(
                dialogue_context=context,
                knowledge_text=kg.to_text(),
                response=response,
            ))

        self.h2es.index(database)
        logger.info("Database ready: %d exemplars indexed.", len(database))

    # ------------------------------------------------------------------
    # Core generation
    # ------------------------------------------------------------------

    def generate(self, dialogue_context: str) -> str:
        """
        Generate a faithful doctor response for one dialogue context.

        Parameters
        ----------
        dialogue_context : str
            Full patient–doctor history up to (but not including) the
            target doctor turn.

        Returns
        -------
        str
            Generated doctor response.
        """
        # ── MKE ──
        kg = self.graph_builder.build(dialogue_context)
        knowledge_text = kg.to_text()

        # ── H2ES ──
        ablation = self.cfg.ablation
        exemplars: List[Exemplar] = []

        if ablation in (AblationMode.FULL, AblationMode.NO_KNOWLEDGE):
            exemplars = self.h2es.select(dialogue_context, knowledge_text)

        # ── PC ──
        if ablation == AblationMode.FULL:
            prompt = self.pc.build(dialogue_context, knowledge_text, exemplars)
        elif ablation == AblationMode.NO_KNOWLEDGE:
            prompt = self.pc.build_no_knowledge(dialogue_context, exemplars)
        elif ablation == AblationMode.NO_EXEMPLARS:
            prompt = self.pc.build_no_exemplars(dialogue_context, knowledge_text)
        else:  # VANILLA
            prompt = self.pc.build_vanilla(dialogue_context)

        # ── LLM ──
        return self.llm.generate(prompt)

    def generate_batch(self, dialogue_contexts: List[str]) -> List[str]:
        """Generate responses for a list of dialogue contexts."""
        return [self.generate(ctx) for ctx in dialogue_contexts]
