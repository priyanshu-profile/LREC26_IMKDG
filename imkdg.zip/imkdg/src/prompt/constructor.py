"""
src/prompt/constructor.py

Prompt Construction (PC) module — Section 3.2 of the paper.

Assembles the final few-shot prompt fed to the LLM:

    R = LLM(I \\n PE_1 \\n ... \\n PE_l \\n P_input)

where:
  I       = task-specific instruction
  PE_j    = formatted exemplar j  (dialogue context + knowledge + response)
  P_input = formatted target context (response left blank for the LLM)
"""

from __future__ import annotations

from typing import List

from src.exemplar.h2es import Exemplar


# ---------------------------------------------------------------------------
# Prompt templates (matches Figure 3 in the paper)
# ---------------------------------------------------------------------------

INSTRUCTION = (
    "Generate the Doctor's response for the following patient–doctor "
    "conversation based on the given examples and the provided medical "
    "knowledge. Base your response strictly on the knowledge and context given."
)


def _format_dialogue(context: str) -> str:
    """Return the dialogue context block with 'Patient:' / 'Doctor:' markers."""
    return f"Dialogue Context\n{context.strip()}"


def _format_knowledge(knowledge_text: str) -> str:
    """Return the 'We know that:' knowledge block."""
    if not knowledge_text.strip():
        return ""
    return f"We know that:\n{knowledge_text.strip()}"


def _format_exemplar(exemplar: Exemplar) -> str:
    """
    Format a single in-context exemplar as it appears in Figure 3.

    Output structure::
        Dialogue Context
        Patient: ...
        Doctor: ...
        We know that:
        [triplet1], [triplet2], ...
        Doctor Response: <ground-truth>
    """
    parts = [
        _format_dialogue(exemplar.dialogue_context),
        _format_knowledge(exemplar.knowledge_text),
        f"Doctor Response: {exemplar.response.strip()}",
    ]
    return "\n".join(p for p in parts if p)


def _format_target(context: str, knowledge_text: str) -> str:
    """
    Format the target context — identical to an exemplar but with
    'Doctor Response:' left blank for the LLM to complete.
    """
    parts = [
        _format_dialogue(context),
        _format_knowledge(knowledge_text),
        "Doctor Response:",            # ← LLM fills this in
    ]
    return "\n".join(p for p in parts if p)


# ---------------------------------------------------------------------------
# PromptConstructor
# ---------------------------------------------------------------------------

class PromptConstructor:
    """
    Builds the final prompt string from instruction + exemplars + target.

    Parameters
    ----------
    instruction : str
        Task-specific instruction prepended to the prompt.
        Override if you want to customise the instruction wording.
    separator : str
        String inserted between prompt blocks. Default: ``"\\n\\n"``.
    """

    def __init__(
        self,
        instruction: str = INSTRUCTION,
        separator: str = "\n\n",
    ):
        self.instruction = instruction.strip()
        self.separator = separator

    def build(
        self,
        target_context: str,
        target_knowledge: str,
        exemplars: List[Exemplar],
    ) -> str:
        """
        Construct the full prompt.

        Parameters
        ----------
        target_context : str
            Dialogue history of the instance to be generated.
        target_knowledge : str
            Serialised knowledge triplets for the target instance.
        exemplars : list of Exemplar
            In-context exemplars returned by H2ES, in the order they
            should appear in the prompt (closest first, per paper).

        Returns
        -------
        str
            The complete prompt ready to be sent to an LLM.
        """
        blocks: List[str] = [self.instruction]

        # ── ICL exemplars ──
        for ex in exemplars:
            blocks.append(_format_exemplar(ex))

        # ── Target context ──
        blocks.append(_format_target(target_context, target_knowledge))

        return self.separator.join(blocks)

    def build_no_knowledge(
        self,
        target_context: str,
        exemplars: List[Exemplar],
    ) -> str:
        """
        Ablation: prompt without medical knowledge (IMKDG w/o K).
        Exemplars still included, but 'We know that:' blocks omitted.
        """
        dummy = [
            Exemplar(
                dialogue_context=ex.dialogue_context,
                knowledge_text="",
                response=ex.response,
            )
            for ex in exemplars
        ]
        return self.build(target_context, "", dummy)

    def build_no_exemplars(
        self,
        target_context: str,
        target_knowledge: str,
    ) -> str:
        """
        Ablation: prompt without in-context exemplars (IMKDG w/o E).
        Knowledge included, but zero-shot.
        """
        return self.build(target_context, target_knowledge, exemplars=[])

    def build_vanilla(self, target_context: str) -> str:
        """
        Baseline: vanilla LLM prompt — no knowledge, no exemplars.
        Corresponds to 'vanilla LLMs' rows in Tables 1 & 2.
        """
        return self.build(target_context, "", exemplars=[])
