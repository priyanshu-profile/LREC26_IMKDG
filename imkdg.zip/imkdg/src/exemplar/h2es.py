"""
src/exemplar/h2es.py

Homo-Heterogeneous Exemplar Selection (H2ES) — Algorithm 1 from the paper.

The algorithm selects l exemplars from a database D that are:
  - *Relevant*  (high cosine similarity to the query in RoBERTa embedding space)
  - *Diverse*   (high Manhattan distance from already-selected exemplars)

The final score balances both objectives (Eq. 5):

    F_score = (1 - λ) * Div_score + λ * Sim(q, E_i)

where λ ∈ [0, 1] controls the relevance / diversity trade-off.
The paper empirically sets λ = 0.2.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import torch

from src.exemplar.encoder import SentenceEncoder

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Exemplar:
    """
    A single in-context exemplar as stored in the reference database.

    Attributes
    ----------
    dialogue_context : str
        The patient–doctor dialogue history (all turns except the target response).
    knowledge_text : str
        Serialised knowledge triplets for this instance ("We know that: [...]").
    response : str
        Ground-truth doctor response.
    embedding : torch.Tensor | None
        Pre-computed unit-norm sentence embedding of (dialogue_context + knowledge_text).
    metadata : dict
        Optional fields (dataset name, sample id, …).
    """
    dialogue_context: str
    knowledge_text: str
    response: str
    embedding: Optional[torch.Tensor] = field(default=None, repr=False)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def combined_text(self) -> str:
        """Concatenation used to build the semantic embedding (query q)."""
        return f"{self.dialogue_context} {self.knowledge_text}"


# ---------------------------------------------------------------------------
# H2ES
# ---------------------------------------------------------------------------

class H2ES:
    """
    Homo-Heterogeneous Exemplar Selection (Algorithm 1).

    Parameters
    ----------
    encoder : SentenceEncoder
        Pre-loaded RoBERTa encoder (shared with the rest of the pipeline).
    n_relevant : int
        L — size of the initial relevant pool.
    n_exemplars : int
        l — number of final diverse exemplars to return (l ≪ L).
    lambda_ : float
        λ — trade-off between relevance (high λ) and diversity (low λ).
        Paper empirically sets λ = 0.2.
    """

    def __init__(
        self,
        encoder: SentenceEncoder,
        n_relevant: int = 20,
        n_exemplars: int = 3,
        lambda_: float = 0.2,
    ):
        if n_exemplars > n_relevant:
            raise ValueError(f"n_exemplars ({n_exemplars}) must be ≤ n_relevant ({n_relevant})")
        self.encoder = encoder
        self.L = n_relevant
        self.l = n_exemplars
        self.lambda_ = lambda_

    # ------------------------------------------------------------------
    # Database indexing
    # ------------------------------------------------------------------

    def index(self, database: List[Exemplar]) -> None:
        """
        Pre-compute and cache sentence embeddings for all database instances.

        Call this once after building the exemplar database (training set).

        Parameters
        ----------
        database : list of Exemplar
            All training instances with ``dialogue_context`` and
            ``knowledge_text`` filled in.
        """
        logger.info("Indexing %d exemplars …", len(database))
        texts = [ex.combined_text for ex in database]
        embeddings = self.encoder.encode(texts)   # (N, H)
        for ex, emb in zip(database, embeddings):
            ex.embedding = emb
        self._database = database
        self._db_matrix = embeddings              # (N, H) — cached for fast retrieval
        logger.info("Indexing complete.")

    # ------------------------------------------------------------------
    # Core algorithm (Algorithm 1)
    # ------------------------------------------------------------------

    def select(
        self,
        query_context: str,
        query_knowledge: str,
        exclude_ids: Optional[set] = None,
    ) -> List[Exemplar]:
        """
        Run H2ES for a single query and return l diverse, relevant exemplars.

        Parameters
        ----------
        query_context : str
            Dialogue context of the *target* instance.
        query_knowledge : str
            Knowledge triplets of the *target* instance.
        exclude_ids : set of int | None
            Indices in the database to exclude (e.g. the target itself).

        Returns
        -------
        List[Exemplar]
            Ordered list of l exemplars, sorted by descending final score
            (most relevant/diverse last, per the paper's prompt ordering).
        """
        if not hasattr(self, "_database"):
            raise RuntimeError("Call h2es.index(database) before h2es.select().")

        query_text = f"{query_context} {query_knowledge}"
        q_emb = self.encoder.encode(query_text).squeeze(0)          # (H,)

        # ── Step 3-8: compute similarity scores, select top-L pool ──
        sim_scores = self.encoder.cosine_similarity(q_emb, self._db_matrix)  # (N,)

        if exclude_ids:
            for idx in exclude_ids:
                sim_scores[idx] = -1.0

        # Indices of top-L relevant exemplars
        top_l_indices = torch.topk(sim_scores, k=min(self.L, len(self._database))).indices.tolist()

        # ── Step 9: seed queue with highest-similarity exemplar ──
        queue: List[int] = [top_l_indices[0]]
        remaining: List[int] = top_l_indices[1:]

        # ── Step 10-17: iteratively add most diverse+relevant exemplar ──
        while len(queue) < self.l and remaining:
            last_emb = self._database[queue[-1]].embedding.unsqueeze(0)  # (1, H)

            # Embeddings of remaining candidates
            cand_embs = torch.stack([self._database[i].embedding for i in remaining])  # (M, H)

            # Diversity: Manhattan distance from the last-selected exemplar (Eq. 5)
            div_scores = self.encoder.manhattan_distance(last_emb, cand_embs).squeeze(0)  # (M,)

            # Normalise diversity to [0, 1] for fair combination
            div_max = div_scores.max().clamp(min=1e-9)
            div_norm = div_scores / div_max

            # Relevance scores for the remaining candidates
            rel_scores = sim_scores[torch.tensor(remaining)]                              # (M,)

            # Final score (Eq. 5)
            f_scores = (1 - self.lambda_) * div_norm + self.lambda_ * rel_scores

            best_local_idx = f_scores.argmax().item()
            best_global_idx = remaining[best_local_idx]

            queue.append(best_global_idx)
            remaining.pop(best_local_idx)

        # The paper places exemplars in *descending* order of final score in the prompt.
        # The queue is already ordered from most-similar (index 0) to most-diverse (last).
        # We reverse so that the most relevant exemplar sits closest to the target context.
        selected = [self._database[i] for i in reversed(queue)]
        return selected

    # ------------------------------------------------------------------
    # Batch selection (convenience)
    # ------------------------------------------------------------------

    def select_batch(
        self,
        queries: List[Dict[str, str]],
    ) -> List[List[Exemplar]]:
        """
        Select exemplars for a list of queries.

        Parameters
        ----------
        queries : list of dict
            Each dict must have keys ``"context"`` and ``"knowledge"``.

        Returns
        -------
        List of exemplar lists (one per query).
        """
        return [
            self.select(q["context"], q["knowledge"])
            for q in queries
        ]
