"""
src/exemplar/encoder.py

RoBERTa-based sentence encoder used by H2ES to compute
semantic representations of dialogue + knowledge instances.

The paper uses RoBERTa (Liu et al., 2019) as the sentence encoder (Enc)
and cosine similarity to retrieve relevant exemplars (Eq. 4).
"""

from __future__ import annotations

import logging
from typing import List, Union

import torch
import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer

logger = logging.getLogger(__name__)


class SentenceEncoder(torch.nn.Module):
    """
    Mean-pooled RoBERTa sentence encoder.

    Produces a fixed-size embedding for any text string by mean-pooling
    the last hidden states of a pre-trained RoBERTa model.

    Parameters
    ----------
    model_name : str
        HuggingFace model identifier. Default: ``"roberta-base"``.
    device : str
        Torch device. Default: ``"cuda"`` (falls back to ``"cpu"``).
    max_length : int
        Maximum tokenisation length. Default: 512.
    batch_size : int
        Encoding batch size for large collections.
    """

    def __init__(
        self,
        model_name: str = "roberta-base",
        device: str = "cuda",
        max_length: int = 512,
        batch_size: int = 64,
    ):
        super().__init__()
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.max_length = max_length
        self.batch_size = batch_size

        logger.info("Loading encoder: %s on %s", model_name, self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(self.device)
        self.model.eval()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _mean_pool(token_embeddings: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        """
        Mean-pool token embeddings, ignoring padding tokens.

        Parameters
        ----------
        token_embeddings : Tensor of shape (B, L, H)
        attention_mask   : Tensor of shape (B, L)

        Returns
        -------
        Tensor of shape (B, H)
        """
        mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        summed = torch.sum(token_embeddings * mask, dim=1)
        counts = torch.clamp(mask.sum(dim=1), min=1e-9)
        return summed / counts

    def _encode_batch(self, texts: List[str]) -> torch.Tensor:
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        ).to(self.device)

        with torch.no_grad():
            outputs = self.model(**encoded)

        embeddings = self._mean_pool(outputs.last_hidden_state, encoded["attention_mask"])
        return F.normalize(embeddings, p=2, dim=-1)   # L2-normalise for cosine sim

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def encode(self, texts: Union[str, List[str]]) -> torch.Tensor:
        """
        Encode one or more texts into unit-norm sentence embeddings.

        Parameters
        ----------
        texts : str or list of str

        Returns
        -------
        Tensor of shape (N, hidden_size) where N = len(texts).
        """
        if isinstance(texts, str):
            texts = [texts]

        all_embeddings: List[torch.Tensor] = []
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i : i + self.batch_size]
            all_embeddings.append(self._encode_batch(batch))

        return torch.cat(all_embeddings, dim=0)   # (N, H)

    def cosine_similarity(self, query: torch.Tensor, keys: torch.Tensor) -> torch.Tensor:
        """
        Compute cosine similarity between a query vector and a matrix of key vectors.

        Parameters
        ----------
        query : Tensor of shape (H,) or (1, H)
        keys  : Tensor of shape (N, H)

        Returns
        -------
        Tensor of shape (N,) with similarity scores in [-1, 1].
        """
        query = query.view(1, -1)                   # (1, H)
        return (query @ keys.T).squeeze(0)           # (N,)

    def manhattan_distance(self, a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
        """
        Pairwise Manhattan (L1) distance between rows of ``a`` and ``b``.

        The paper computes Manhattan distance as the *diversity* score
        between exemplar embeddings (Section 3.2 / Algorithm 1, step 12).

        Parameters
        ----------
        a : Tensor of shape (M, H)
        b : Tensor of shape (N, H)

        Returns
        -------
        Tensor of shape (M, N) — distance[i, j] = ||a[i] - b[j]||_1
        """
        # Expand to (M, N, H) for broadcasting
        return torch.abs(a.unsqueeze(1) - b.unsqueeze(0)).sum(dim=-1)

    def forward(self, texts: Union[str, List[str]]) -> torch.Tensor:
        return self.encode(texts)
