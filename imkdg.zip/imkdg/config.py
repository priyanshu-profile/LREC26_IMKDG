"""
config.py — Central configuration for IMKDG.

All paths, hyperparameters, and model choices live here.
Override via CLI arguments in main.py or environment variables.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# Path to the local QuickUMLS installation (UMLS Metathesaurus snapshot).
# Follow: https://github.com/Georgetown-IR-Lab/QuickUMLS#installation
QUICKUMLS_PATH: str = "/path/to/quickumls/data"  # ← update this

# ---------------------------------------------------------------------------
# Encoder
# ---------------------------------------------------------------------------
ENCODER_MODEL: str = "roberta-base"         # Sentence encoder (H2ES)
ENCODER_DEVICE: str = "cuda"                # "cuda" | "cpu" | "mps"
ENCODER_BATCH_SIZE: int = 64

# ---------------------------------------------------------------------------
# H2ES hyperparameters (Section 3.2, Eq. 5)
# ---------------------------------------------------------------------------
@dataclass
class H2ESConfig:
    n_relevant: int   = 20     # L  — pool of relevant exemplars
    n_exemplars: int  = 3      # l  — final diverse subset
    lambda_: float    = 0.2    # λ  — relevance/diversity trade-off


# ---------------------------------------------------------------------------
# Supported LLMs
# ---------------------------------------------------------------------------
SUPPORTED_LLMS = {
    "biogpt":      "microsoft/biogpt",
    "medalpaca":   "medalpaca/medalpaca-7b",
    "chatdoctor":  "zl111/ChatDoctor",
    "chatgpt":     "gpt-3.5-turbo",          # OpenAI API
    "pmc-llama":   "axiong/PMC_LLaMA_13B",
    "medpalm2":    "google/medpalm2",        # requires Google access
    "gpt-4":       "gpt-4-turbo",            # OpenAI API
}

# OpenAI API key (set via environment: export OPENAI_API_KEY=...)
import os
OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")

# ---------------------------------------------------------------------------
# Datasets
# ---------------------------------------------------------------------------
SUPPORTED_DATASETS = {
    "meddialog": {
        "hf_name": "bigbio/med_dialog",
        "hf_config": "med_dialog_en_bigbio_qa",
        "local_path": DATA_DIR / "meddialog",
    },
    "cdialog": {
        "local_path": DATA_DIR / "cdialog",
    },
}

TRAIN_SPLIT: float = 0.7    # paper: 7:3 train/test
DEV_SPLIT: float   = 0.2    # of training portion

# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------
GENERATION_TEMPERATURE: float = 0.0    # paper: temperature=0
MAX_NEW_TOKENS: int           = 512

# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
SCISPACY_MODEL: str = "en_core_sci_sm"    # for E-F1 NER
BERTSCORE_MODEL: str = "roberta-large"

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
SEED: int = 42
